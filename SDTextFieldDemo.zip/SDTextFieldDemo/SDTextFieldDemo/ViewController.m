//
//  ViewController.m
//  SDTextFieldDemo
//
//  Created by songjc on 16/10/11.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "ViewController.h"
#import "SDTextField.h"
@interface ViewController ()


@property(nonatomic,strong)SDTextField *textField;
@property(nonatomic,strong)SDTextField *textField1;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"背景.jpeg"]];
    
    self.textField = [SDTextField initWithFrame:CGRectMake(75, 100, 250, 35)];
    
    self.textField.textfield.placeholder = @"请输入账号";
    
    self.textField.dataArray = [NSMutableArray arrayWithArray:@[@"a",@"ab",@"A",@"c",@"admin"]];
    
    self.textField.heightMultiple = 4;
    
    [self.view addSubview:self.textField];
    
    self.textField1 = [[SDTextField alloc]initWithFrame:CGRectMake(75, 150, 250, 35)];
    
    self.textField1.textfield.placeholder = @"请输入密码";
    
    self.textField1.dataArray = [NSMutableArray arrayWithArray:@[@"a",@"ab",@"A",@"c",@"123"]];
    
    [self.view addSubview:self.textField1];


}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.textField endEditing:YES];
    [self.textField1 endEditing:YES];


}



@end
